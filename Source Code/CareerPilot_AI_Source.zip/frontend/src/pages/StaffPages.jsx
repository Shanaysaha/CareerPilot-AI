import { useEffect, useState } from "react";
import { ArrowRight, Bell, BriefcaseBusiness, CheckCircle2, Plus, Send, Users, Archive, BarChart3 } from "lucide-react";
import { api } from "../api.js";
import { useAuth } from "../AuthContext.jsx";
import { Button, EmptyState, Field, MetricCard, PageHeading, Panel, StatusMessage } from "../components.jsx";
import { formatDate, useRemote } from "../useRemote.js";

// Display cohort-level placement progress for an officer or administrator.
export function StaffDashboardPage() {
  const { user } = useAuth();
  const isAdmin = user?.role === "administrator";
  const { data, loading, error, refresh } = useRemote("/officer/cohorts");
  const [dashboard, setDashboard] = useState([]);
  const [summary, setSummary] = useState(null);
  const [students, setStudents] = useState([]);
  const [selectedId, setSelectedId] = useState("");
  const [notices, setNotices] = useState([]);
  const [message, setMessage] = useState("");
  const [problem, setProblem] = useState("");
  const [busy, setBusy] = useState(false);
  const cohorts = data?.cohorts || [];

  // Load cohort totals and current notice list for this user's permitted scope.
  useEffect(() => {
    Promise.all([api("/officer/dashboard"), api("/officer/notifications")]).then(([stats, noticeData]) => {
      setDashboard(stats.cohorts || []); setNotices(noticeData.notifications || []);
    }).catch((reason) => setProblem(reason.message));
  }, []);

  // Load the selected cohort's student list and summary counts.
  useEffect(() => {
    if (!selectedId) { setStudents([]); setSummary(null); return; }
    Promise.all([api(`/officer/cohorts/${selectedId}/students`), api(`/officer/reports/summary?cohortId=${selectedId}`)])
      .then(([studentData, reportData]) => { setStudents(studentData.students || []); setSummary(reportData.summary); })
      .catch((reason) => setProblem(reason.message));
  }, [selectedId]);

  // Publish a notice to the selected cohort, or globally for administrators.
  async function publishNotice(event) {
    event.preventDefault(); setBusy(true); setProblem(""); setMessage("");
    const form = new FormData(event.currentTarget);
    const cohortId = form.get("cohortId") || selectedId || null;
    try {
      await api("/officer/notifications", { method: "POST", body: { title: form.get("title"), body: form.get("body"), cohortId } });
      setMessage("Notification published."); event.currentTarget.reset();
      const updated = await api("/officer/notifications"); setNotices(updated.notifications || []);
    } catch (reason) { setProblem(reason.message); }
    finally { setBusy(false); }
  }

  // Administrators can assign an existing student to a managed cohort.
  async function updateStudentCohort(studentId, cohortId) {
    setProblem("");
    try { await api(`/officer/students/${studentId}/cohort`, { method: "PATCH", body: { cohortId: cohortId || null } }); setMessage("Student cohort assignment updated."); }
    catch (reason) { setProblem(reason.message); }
  }

  return <>
    <PageHeading title={isAdmin ? "Placement administration" : "Placement workspace"} subtitle="Review cohort progress and share relevant placement updates." art="phone"/>
    <StatusMessage tone="error">{error || problem}</StatusMessage><StatusMessage tone="success">{message}</StatusMessage>
    <div className="metric-grid"><MetricCard label="Your cohorts" value={cohorts.length} caption="assigned and active" icon={BriefcaseBusiness} color="violet"/><MetricCard label="Students" value={dashboard.reduce((sum, cohort) => sum + Number(cohort.students || 0), 0)} caption="in your cohort scope" icon={Users} color="blue"/><MetricCard label="Ready evidence" value={dashboard.reduce((sum, cohort) => sum + Number(cohort.studentsWithReadiness || 0), 0)} caption="students with a readiness snapshot" icon={CheckCircle2} color="green"/><MetricCard label="Published notices" value={notices.filter((item) => item.isPublished).length} caption="visible in your scope" icon={Bell} color="orange"/></div>
    <div className="staff-grid"><Panel title="Cohort overview" subtitle="Select a cohort to review its student list and summary report."><div className="field"><span>Choose cohort</span><select value={selectedId} onChange={(event) => setSelectedId(event.target.value)}><option value="">Select a cohort</option>{cohorts.map((cohort) => <option value={cohort.id} key={cohort.id}>{cohort.name} {cohort.academicYear ? `· ${cohort.academicYear}` : ""}</option>)}</select></div>{loading ? <p>Loading cohorts…</p> : dashboard.length ? <div className="staff-cohort-list">{dashboard.map((cohort) => <button className={selectedId === cohort.cohortId ? "staff-cohort active" : "staff-cohort"} onClick={() => setSelectedId(cohort.cohortId)} key={cohort.cohortId}><span><strong>{cohort.cohort}</strong><small>{cohort.students} students · {cohort.studentsWithReadiness} readiness summaries</small></span><ArrowRight size={17}/></button>)}</div> : <EmptyState icon={BriefcaseBusiness} title="No cohorts in this scope">An administrator can create a cohort and assign an officer.</EmptyState>}</Panel><Panel title="Cohort summary" subtitle={selectedId ? "Readiness information for the selected cohort." : "Select a cohort to show its summary."}>{summary ? <div className="summary-stats"><div><strong>{summary.students}</strong><span>Students</span></div><div><strong>{summary.completeReadiness}</strong><span>Complete readiness</span></div><div><strong>{summary.averageReadiness ?? "—"}{summary.averageReadiness === null ? "" : "%"}</strong><span>Average readiness</span></div><div><strong>{summary.studentsWithResume}</strong><span>With resume activity</span></div></div> : <EmptyState icon={Users} title="No cohort selected">Choose one above to review summary metrics.</EmptyState>}</Panel></div>
    {selectedId && <Panel title="Students in this cohort" subtitle="Placement officers can review cohort-level data. Resume files remain private to students.">{students.length ? <div className="table-wrap"><table><thead><tr><th>Student</th><th>Email</th><th>Course</th><th>Target role</th><th>Readiness</th>{isAdmin && <th>Cohort assignment</th>}</tr></thead><tbody>{students.map((student) => <tr key={student.id}><td>{student.fullName}</td><td>{student.email}</td><td>{student.course || "—"}</td><td>{student.targetRole || "—"}</td><td>{student.readinessScore ?? "—"}{student.readinessScore === null ? "" : "%"}</td>{isAdmin && <td><select defaultValue={selectedId} onChange={(event) => updateStudentCohort(student.id, event.target.value)}><option value={selectedId}>{cohorts.find((item) => item.id === selectedId)?.name}</option><option value="">Unassign</option></select></td>}</tr>)}</tbody></table></div> : <EmptyState icon={Users} title="No students assigned yet">Students appear after the administrator assigns them to this cohort.</EmptyState>}</Panel>}
    <div className="staff-grid"><Panel title="Publish a notification" subtitle={isAdmin ? "Choose a cohort or leave it blank to send institution-wide." : "This notice will be delivered to your selected cohort."}><form onSubmit={publishNotice}><Field label="Title"><input name="title" maxLength="160" required placeholder="Placement update"/></Field>{isAdmin && <Field label="Delivery group"><select name="cohortId" defaultValue=""><option value="">All students (administrator only)</option>{cohorts.map((cohort) => <option value={cohort.id} key={cohort.id}>{cohort.name}</option>)}</select></Field>}<Field label="Message"><textarea name="body" rows="4" required maxLength="5000" placeholder="Share an update with students…"/></Field><Button type="submit" disabled={busy}><Send size={17}/>{busy ? "Publishing…" : "Publish notification"}</Button></form></Panel><Panel title="Recent notifications" subtitle="Notices you have created or that belong to assigned cohorts.">{notices.slice(0, 5).length ? <div className="notice-list">{notices.slice(0, 5).map((notice) => <article className="notice-row" key={notice.id}><span className="feature-icon tone-violet"><Bell size={19}/></span><div><strong>{notice.title}</strong><small>{notice.cohort || "Institution-wide"} · {formatDate(notice.publishedAt)}</small></div></article>)}</div> : <EmptyState icon={Bell} title="No notices yet">Publish a cohort update when you are ready.</EmptyState>}</Panel></div>
    {isAdmin && <AdminTools cohorts={cohorts} onCreated={refresh} setMessage={setMessage} setProblem={setProblem}/>}
  </>;
}

// Let administrators create cohorts and staff accounts, then assign officers.
function AdminTools({ cohorts, onCreated, setMessage, setProblem }) {
  const [busy, setBusy] = useState(false);
  const [officers, setOfficers] = useState([]);
  const [cohortId, setCohortId] = useState("");
  // Read officers assigned to cohorts, because the backend exposes them through each cohort.
  useEffect(() => {
    if (!cohorts.length) return;
    Promise.all(cohorts.map((cohort) => api(`/officer/cohorts/${cohort.id}/officers`)))
      .then((results) => {
        const unique = new Map();
        results.forEach((result) => (result.officers || []).forEach((officer) => unique.set(officer.id, officer)));
        setOfficers([...unique.values()]);
      })
      .catch(() => {});
  }, [cohorts]);

  // Create a new cohort from the name and optional academic year.
  async function createCohort(event) {
    event.preventDefault(); setBusy(true); setProblem(""); setMessage("");
    const form = new FormData(event.currentTarget);
    try { await api("/officer/cohorts", { method: "POST", body: { name: form.get("name"), academicYear: form.get("academicYear") } }); event.currentTarget.reset(); setMessage("Cohort created."); await onCreated(); }
    catch (reason) { setProblem(reason.message); }
    finally { setBusy(false); }
  }

  // Create a placement officer account using a temporary password for first sign-in.
  async function createOfficer(event) {
    event.preventDefault(); setBusy(true); setProblem(""); setMessage("");
    const form = new FormData(event.currentTarget);
    try { const result = await api("/officer/users", { method: "POST", body: { fullName: form.get("fullName"), email: form.get("email"), role: "placement_officer", temporaryPassword: form.get("temporaryPassword") } }); setOfficers((items) => [...items, result.user]); event.currentTarget.reset(); setMessage("Placement officer account created."); }
    catch (reason) { setProblem(reason.message); }
    finally { setBusy(false); }
  }

  // Give an active placement officer access to the currently selected cohort.
  async function assignOfficer(event) {
    event.preventDefault(); setBusy(true); setProblem(""); setMessage("");
    const form = new FormData(event.currentTarget);
    try {
      await api(`/officer/officers/${form.get("officerId")}/cohorts`, { method: "POST", body: { cohortId: form.get("cohortId") } });
      setMessage("Officer assigned to the cohort.");
      const results = await Promise.all(cohorts.map((item) => api(`/officer/cohorts/${item.id}/officers`)));
      const unique = new Map();
      results.forEach((result) => (result.officers || []).forEach((officer) => unique.set(officer.id, officer)));
      setOfficers([...unique.values()]);
    }
    catch (reason) { setProblem(reason.message); }
    finally { setBusy(false); }
  }

  return <Panel title="Administrator tools" subtitle="Set up cohorts and placement officer access."><div className="admin-tools-grid"><form onSubmit={createCohort}><h3><Plus size={18}/> Create cohort</h3><Field label="Cohort name"><input name="name" required maxLength="120" placeholder="2027 Computer Science"/></Field><Field label="Academic year"><input name="academicYear" maxLength="20" placeholder="2026–2027"/></Field><Button type="submit" disabled={busy}>Create cohort</Button></form><form onSubmit={createOfficer}><h3><Users size={18}/> Create placement officer</h3><Field label="Full name"><input name="fullName" required maxLength="120"/></Field><Field label="Email"><input name="email" type="email" required/></Field><Field label="Temporary password"><input name="temporaryPassword" type="password" minLength="12" required/><small>Share it with the officer through a private channel.</small></Field><Button type="submit" disabled={busy}>Create officer</Button></form><form onSubmit={assignOfficer}><h3><BriefcaseBusiness size={18}/> Assign officer</h3><Field label="Officer"><select name="officerId" required defaultValue=""><option value="" disabled>Choose an officer</option>{officers.map((item) => <option key={item.id} value={item.id}>{item.fullName} · {item.email}</option>)}</select></Field><Field label="Cohort"><select name="cohortId" required value={cohortId} onChange={(event) => setCohortId(event.target.value)}><option value="" disabled>Choose a cohort</option>{cohorts.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></Field><Button type="submit" disabled={busy}>Assign access</Button></form></div></Panel>;
}

// Show readiness and resume coverage using only the selected cohort report API.
export function StaffReportsPage() {
  const { data: cohortData, loading, error } = useRemote("/officer/cohorts");
  const cohorts = cohortData?.cohorts || [];
  const [selectedId, setSelectedId] = useState("");
  const [report, setReport] = useState(null);
  const [problem, setProblem] = useState("");

  // Load the aggregate report for the selected cohort, or the officer's full scope.
  useEffect(() => {
    setProblem("");
    api(`/officer/reports/summary${selectedId ? `?cohortId=${selectedId}` : ""}`)
      .then((result) => setReport(result.summary))
      .catch((reason) => setProblem(reason.message));
  }, [selectedId]);

  const measures = [
    ["Students", Number(report?.students || 0), "tone-violet"],
    ["Average readiness", Number(report?.averageReadiness || 0), "tone-green"],
    ["Complete readiness", Number(report?.completeReadiness || 0), "tone-blue"],
    ["Resume activity", Number(report?.studentsWithResume || 0), "tone-orange"],
  ];

  return <>
    <PageHeading title="Reports & readiness analytics" subtitle="Review the preparation evidence available for your cohort scope." art="results"/>
    <StatusMessage tone="error">{error || problem}</StatusMessage>
    <Panel title="Choose a cohort" subtitle="The report updates from the backend data when you select a group."><Field label="Cohort"><select value={selectedId} onChange={(event) => setSelectedId(event.target.value)}><option value="">All assigned cohorts</option>{cohorts.map((item) => <option value={item.id} key={item.id}>{item.name} {item.academicYear ? `· ${item.academicYear}` : ""}</option>)}</select></Field></Panel>
    <div className="metric-grid">{measures.map(([label, value, color]) => <MetricCard key={label} label={label} value={label === "Average readiness" ? `${value}%` : value} caption={label === "Resume activity" ? "students with a saved resume" : "current cohort report"} icon={BarChart3} color={color.replace("tone-", "")}/>)}</div>
    <Panel title="Cohort overview" subtitle={loading ? "Loading cohorts…" : "Average readiness by cohort, based on available student evidence."}>{cohorts.length ? <div className="report-bars">{cohorts.map((cohort) => <div className="report-bar" key={cohort.id}><span>{cohort.name}</span><div><i style={{ width: `${Math.min(100, Number(cohort.averageReadiness || 0))}%` }}/></div><strong>{cohort.averageReadiness ?? 0}%</strong><small>{cohort.students || 0} students</small></div>)}</div> : <EmptyState icon={BriefcaseBusiness} title="No cohorts available">Your administrator can assign a cohort to your account.</EmptyState>}</Panel>
  </>;
}

// Publish, review, and archive placement notices using the staff notification API.
export function StaffNotificationsPage() {
  const { data, loading, error, refresh } = useRemote("/officer/notifications");
  const { data: cohortData } = useRemote("/officer/cohorts");
  const { user } = useAuth();
  const isAdmin = user?.role === "administrator";
  const cohorts = cohortData?.cohorts || [];
  const notices = data?.notifications || [];
  const [message, setMessage] = useState("");
  const [problem, setProblem] = useState("");
  const [busy, setBusy] = useState(false);
  const [editingNotice, setEditingNotice] = useState(null);
  const [noticeFilter, setNoticeFilter] = useState("all");

  // Publish a notice to a selected cohort or to all students as an administrator.
  async function publish(event) {
    event.preventDefault(); setBusy(true); setProblem(""); setMessage("");
    const form = new FormData(event.currentTarget);
    try {
      const payload = { title: form.get("title"), body: form.get("body"), cohortId: form.get("cohortId") || null, isPublished: form.get("status") === "published" };
      await api(editingNotice ? `/officer/notifications/${editingNotice.id}` : "/officer/notifications", { method: editingNotice ? "PATCH" : "POST", body: payload });
      event.currentTarget.reset(); setEditingNotice(null); setMessage(payload.isPublished ? "Placement update published." : "Draft saved."); await refresh();
    } catch (reason) { setProblem(reason.message); }
    finally { setBusy(false); }
  }

  // Archive a notice when the backend allows the current account to manage it.
  async function archive(id) {
    setProblem("");
    try { await api(`/officer/notifications/${id}/archive`, { method: "PATCH" }); setMessage("Notification archived."); await refresh(); }
    catch (reason) { setProblem(reason.message); }
  }

  const filteredNotices = notices.filter((notice) => noticeFilter === "all" || (noticeFilter === "published" && notice.isPublished && !notice.archivedAt) || (noticeFilter === "drafts" && !notice.isPublished && !notice.archivedAt) || (noticeFilter === "archived" && Boolean(notice.archivedAt)));
  const noticeFilters = [["all", `All (${notices.length})`], ["published", `Published (${notices.filter((item) => item.isPublished && !item.archivedAt).length})`], ["drafts", `Drafts (${notices.filter((item) => !item.isPublished && !item.archivedAt).length})`], ["archived", `Archived (${notices.filter((item) => item.archivedAt).length})`]];

  return <>
    <PageHeading eyebrow="NOTIFICATIONS" title="Manage notifications" subtitle="Create, edit, and review announcements for students." art="phone"/>
    <StatusMessage tone="error">{error || problem}</StatusMessage><StatusMessage tone="success">{message}</StatusMessage>
    <div className="admin-notification-layout"><Panel title={editingNotice ? "Edit notification" : "Create notification"} subtitle="Choose the audience, then save a draft or publish the update."><form key={editingNotice?.id || "new-notice"} onSubmit={publish}><Field label="Title"><input name="title" maxLength="160" required defaultValue={editingNotice?.title || ""} placeholder="e.g. Placement Drive – Infosys"/></Field><Field label="Audience"><select name="cohortId" required={!isAdmin} defaultValue={editingNotice?.cohortId || ""}><option value="" disabled={!isAdmin}>{isAdmin ? "All students (administrator)" : "Choose a cohort"}</option>{cohorts.map((item) => <option key={item.id} value={item.id}>{item.name}</option>)}</select></Field><Field label="Message"><textarea name="body" rows="6" required maxLength="5000" defaultValue={editingNotice?.body || ""} placeholder="Write your announcement…"/></Field><Field label="When to send"><select name="status" defaultValue={editingNotice ? (editingNotice.isPublished ? "published" : "draft") : "published"}><option value="published">Publish now</option><option value="draft">Save as draft</option></select></Field><div className="admin-form-actions"><Button type="submit" disabled={busy}><Send size={16}/>{busy ? "Saving…" : editingNotice ? "Save changes" : "Save notification"}</Button>{editingNotice && <Button type="button" variant="outline" onClick={() => setEditingNotice(null)}>Cancel edit</Button>}</div></form></Panel><Panel title="Notifications" subtitle={loading ? "Loading notifications…" : `${notices.length} notifications in your scope.`}><div className="admin-tabs admin-notice-filters">{noticeFilters.map(([key, label]) => <button key={key} className={noticeFilter === key ? "filter-chip active" : "filter-chip"} onClick={() => setNoticeFilter(key)}>{label}</button>)}</div>{filteredNotices.length ? <div className="admin-item-list">{filteredNotices.map((item) => <article className="admin-item" key={item.id}><span className="feature-icon tone-violet"><Bell size={19}/></span><div><strong>{item.title}</strong><small>{item.cohort || "All students"} · {formatDate(item.publishedAt || item.createdAt)}{item.archivedAt ? " · Archived" : ""}</small><small>{item.body}</small></div><span className={`status-chip ${item.archivedAt ? "badge-red" : item.isPublished ? "badge-green" : "badge-orange"}`}>{item.archivedAt ? "Archived" : item.isPublished ? "Published" : "Draft"}</span>{!item.archivedAt && <div className="table-actions"><Button className="button-small" variant="outline" onClick={() => setEditingNotice(item)}>Edit</Button><Button className="button-small" variant="outline" onClick={() => archive(item.id)}><Archive size={15}/>Archive</Button></div>}</article>)}</div> : <EmptyState icon={Bell} title="No notifications in this view">Create an update or choose a different status filter.</EmptyState>}</Panel></div>
  </>;
}
